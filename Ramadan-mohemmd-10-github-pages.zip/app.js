const defaults=[
{id:1,name:"iPhone 15",price:3200,icon:"📱",desc:"هاتف iPhone 15 بأداء قوي وتصميم عصري."},
{id:2,name:"Samsung Galaxy S24",price:2800,icon:"📱",desc:"هاتف سامسونج Galaxy S24."},
{id:3,name:"Honor X9d",price:1900,icon:"📱",desc:"هاتف Honor X9d ببطارية قوية."},
{id:4,name:"سماعات لاسلكية",price:180,icon:"🎧",desc:"سماعات لاسلكية بجودة صوت ممتازة."},
{id:5,name:"شاحن سريع",price:120,icon:"🔌",desc:"شاحن سريع للهواتف المحمولة."},
{id:6,name:"كابل شحن",price:60,icon:"🔗",desc:"كابل شحن ونقل بيانات."}
];

let products=JSON.parse(localStorage.getItem("trust_products")||"null")||defaults;
let cart=[];
let current=null;
let password=localStorage.getItem("trust_password")||"1234";

function $(id){return document.getElementById(id)}
function go(id,add=true){
  if(!$("welcome")||!$(id))return;
  document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
  $(id).classList.add("active");
  window.scrollTo(0,0);
  if(id==="cart")renderCart();
  if(id==="admin")renderAdmin();
  if(add)history.pushState({page:id},"","#"+id);
}
window.onpopstate=()=>go(location.hash.slice(1)||"welcome",false);

function productHTML(p){
 return `<div class="card"><div class="pic">${escape(p.icon)}</div><h3>${escape(p.name)}</h3><div class="price">${p.price} د.ل</div><button class="btn blue full" onclick="details(${p.id})">عرض المنتج</button></div>`;
}
function renderHome(q=""){
 const s=q.trim().toLowerCase();
 const list=s?products.filter(p=>p.name.toLowerCase().includes(s)):products;
 $("homeProducts").innerHTML=list.map(productHTML).join("")||"<p>لا توجد منتجات.</p>";
}
function renderAll(){$("allProducts").innerHTML=products.map(productHTML).join("")||"<p>لا توجد منتجات.</p>";}
function details(id){
 current=products.find(p=>p.id===id);if(!current)return;
 $("dPic").textContent=current.icon;$("dName").textContent=current.name;
 $("dPrice").textContent=current.price+" د.ل";$("dDesc").textContent=current.desc;go("details");
}
function addCurrent(){
 if(!current)return;
 let x=cart.find(p=>p.id===current.id);
 if(x)x.qty++;else cart.push({...current,qty:1});
 go("cart");
}
function renderCart(){
 if(!cart.length){
  $("cartList").innerHTML='<div class="empty"><div style="font-size:60px">🛒</div><h2>السلة فارغة</h2><button class="btn blue" onclick="go(\'products\')">تصفح المنتجات</button></div>';
  $("cartTotal").innerHTML="";return;
 }
 $("cartList").innerHTML=cart.map(x=>`<div class="cartrow"><div><b>${escape(x.icon)} ${escape(x.name)}</b><div class="price">${x.price} د.ل × ${x.qty}</div></div><button class="btn light" onclick="removeCart(${x.id})">🗑️</button></div>`).join("");
 const total=cart.reduce((s,x)=>s+x.price*x.qty,0);
 $("cartTotal").innerHTML=`<div class="total"><span>الإجمالي</span><span>${total} د.ل</span></div><br><button class="btn blue full" onclick="go('checkout')">متابعة الطلب</button>`;
}
function removeCart(id){cart=cart.filter(x=>x.id!==id);renderCart();}
function finish(){
 if(!$("name").value.trim()||!$("phone").value.trim()||!$("address").value.trim()){alert("يرجى تعبئة جميع البيانات");return}
 cart=[];go("success");
}
function loginAdmin(){
 if($("adminPass").value===password){$("adminPass").value="";go("admin")}else alert("كلمة المرور غير صحيحة");
}
function logout(){go("home")}
function save(){localStorage.setItem("trust_products",JSON.stringify(products));}
function addProduct(){
 const name=$("newName").value.trim(),price=Number($("newPrice").value),icon=$("newIcon").value.trim()||"📱",desc=$("newDesc").value.trim();
 if(!name||!Number.isFinite(price)||price<0){alert("أدخل الاسم والسعر بشكل صحيح");return}
 products.push({id:Date.now(),name,price,icon,desc});save();renderHome();renderAll();renderAdmin();
 $("newName").value="";$("newPrice").value="";$("newIcon").value="";$("newDesc").value="";
 alert("تمت إضافة المنتج");
}
function renderAdmin(){
 $("adminProducts").innerHTML=products.map(p=>`<div class="adminrow">
<input id="n${p.id}" class="field" value="${escape(p.name)}">
<input id="p${p.id}" class="field" type="number" value="${p.price}">
<input id="i${p.id}" class="field" value="${escape(p.icon)}">
<textarea id="d${p.id}" class="field">${escape(p.desc)}</textarea>
<div class="actions"><button class="btn green" onclick="edit(${p.id})">💾 حفظ</button><button class="btn red" onclick="del(${p.id})">🗑️ حذف</button></div>
</div>`).join("");
}
function edit(id){
 const p=products.find(x=>x.id===id);if(!p)return;
 p.name=$("n"+id).value.trim();p.price=Number($("p"+id).value);p.icon=$("i"+id).value.trim()||"📱";p.desc=$("d"+id).value.trim();
 if(!p.name||!Number.isFinite(p.price)||p.price<0){alert("تحقق من البيانات");return}
 save();renderHome();renderAll();renderAdmin();alert("تم حفظ التعديل");
}
function del(id){
 const p=products.find(x=>x.id===id);if(!p)return;
 if(confirm("حذف "+p.name+"؟")){products=products.filter(x=>x.id!==id);cart=cart.filter(x=>x.id!==id);save();renderHome();renderAll();renderAdmin();}
}
function changePass(){
 const p=$("newPass").value.trim();if(p.length<4){alert("كلمة المرور يجب أن تكون 4 أحرف أو أرقام على الأقل");return}
 password=p;localStorage.setItem("trust_password",p);$("newPass").value="";alert("تم تغيير كلمة المرور");
}
function escape(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

window.addEventListener("DOMContentLoaded",()=>{
 renderHome();renderAll();
 const first=location.hash.slice(1);
 go(first&&$(first)?first:"welcome",false);
});
