# متجر الثقة للهاتف المحمول

مشروع HTML/CSS/JavaScript جاهز للنشر على GitHub Pages.

الملفات:
- `index.html` الواجهات
- `style.css` التصميم
- `app.js` JavaScript والتنقل والسلة ولوحة الإدارة

كلمة مرور لوحة الإدارة الافتراضية: `1234`

بعد رفع الملفات إلى مستودع GitHub Pages:
`https://ramadan1144r-design.github.io/Ramadan-mohemmd-10/`
